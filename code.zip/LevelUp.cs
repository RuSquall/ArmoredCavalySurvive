using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelUp : MonoBehaviour
{
    RectTransform rect;
    Item[] items;
    
    void Awake()
    {
        rect = GetComponent<RectTransform>();
        items = GetComponentsInChildren<Item>(true);
    }

    public void Show()
    {
        Next();
        rect.localScale = Vector3.one;
        GameManager.instance.Stop();
        AudioManager.instance.PlaySfx(AudioManager.Sfx.LevelUp);
        AudioManager.instance.EffectBgm(true);
        
    }
    public void Hide() 
    {
        rect.localScale = Vector3.zero;
        GameManager.instance.Resume();
        AudioManager.instance.EffectBgm(false);
        AudioManager.instance.PlaySfx(AudioManager.Sfx.Select);
        
    }
    public void Select(int index)
    {
        items[index].OnClick();
    }
    void Next()
    {
        List<int> list = new List<int>();
        Debug.Log("List ");
        // 1. ��� ������ ��Ȱ��ȭ
        foreach (Item item in items)
        {
            
            item.gameObject.SetActive(false);
            if(item.level != item.data.damages.Length)
            {
                Debug.Log(item.data.itemId + " " + item.level + " " + item.data.damages.Length);
                list.Add(item.data.itemId);
            }
        }



        Debug.Log("Random List");
        // 2. �� �߿��� ���� 3�� ������ Ȱ��ȭ
        int[] ran = new int[3];
        int cn = 0; //break
        for(int i = 0; i < list.Count && i < ran.Length; i++) // ���� �극��ũ�� �� �ᵵ �ǰ� �ٲٱ�.
        {
            if (cn > 100)
                break;
            cn++;

            ran[i] = list[Random.Range(0, list.Count - 1)];
            for(int j = 0; j < i; j++)
            {
                if (ran[i] == ran[j])
                {
                    Debug.Log("i--");
                    i--;
                    break;
                }
            }
        }
        for(int i = 0; i < ran.Length; i++)
        {
            Debug.Log(ran[i]);
        }
        //while (true)
        //{
        //    ran[0] = Random.Range(0, items.Length);
        //    ran[1] = Random.Range(0, items.Length);
        //    ran[2] = Random.Range(0, items.Length);
            
        //    if (ran[0] != ran[1] && ran[1] != ran[2] && ran[0] != ran[2])
        //        break;
        //}
        for(int index = 0 ; index < ran.Length; index++)
        {
            Item ranItem = items[ran[index]];
            if(ranItem.level == ranItem.data.damages.Length)
            {
                items[items.Length-1].gameObject.SetActive(true);
            }
            else
            {
                ranItem.gameObject.SetActive(true);
            }
            
        }
        // 3. ���� �������� ���� �Һ� ���������� ��ü
    }
}

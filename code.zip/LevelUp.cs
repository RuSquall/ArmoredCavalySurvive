using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelUp : MonoBehaviour
{
    RectTransform rect;
    Item[] items;

    public static int pistolNext = 0;

    
    void Awake()
    {
        rect = GetComponent<RectTransform>();
        items = GetComponentsInChildren<Item>(true);
    }

    public void Show()
    {
        Next();
        rect.localScale = Vector3.one;
        GameManager.instance.Stop();
        AudioManager.instance.PlaySfx(AudioManager.Sfx.LevelUp);
        AudioManager.instance.EffectBgm(true);
        
    }
    public void Hide() 
    {
        rect.localScale = Vector3.zero;
        GameManager.instance.Resume();
        AudioManager.instance.EffectBgm(false);
        AudioManager.instance.PlaySfx(AudioManager.Sfx.Select);
        
    }
    public void Select(int index)
    {
        items[index].OnClick();
        //Debug.Log("Select Item : " + items[index].data.itemName);
    }
    void Next()
    {
        List<int> list = new List<int>();
        // 1. ��� ������ ��Ȱ��ȭ
        foreach (Item item in items)
        {
            item.gameObject.SetActive(false);
            if(item.level != item.data.damages.Length)
            {
                if (item.data.itemId == 2 && pistolNext < 1) continue;
                else if(item.data.itemId == 3 && pistolNext < 2) continue;
                list.Add(item.data.itemId);
                //Debug.Log("list in : " + item.data.itemId);
            }
        }

    
        // �����۷��� 5���� �̸��� �������� 3�� ������ �� list ���� ��� ���ӿ�����Ʈ Ȱ��ȭ
        if (list.Count <= 3)
        {
            for (int i = 0; i < list.Count; i++)
            {
                Item ranItem = items[list[i]];
                ranItem.gameObject.SetActive(true);
            }
        }
        else // 4�� �̻��� �� ���� �迭 ���� �� ����Ʈ �ȿ��� �������� ����
        {
            int[] ran = new int[3];
            int cn = 0; //break
            for (int i = 0; i < list.Count && i < ran.Length; i++)
            {
                if (cn > 100) //������ġ
                {
                    Debug.Log("Count Break!");
                    break;
                }
                    
                cn++;

                ran[i] = list[Random.Range(0, list.Count)];
                for (int j = 0; j < i; j++)
                    if (ran[i] == ran[j])
                    {
                        i--;
                        break;
                    }
            }
            for (int index = 0; index < ran.Length; index++)
            {
                Item ranItem = items[ran[index]];
                ranItem.gameObject.SetActive(true);
            }
        }
    }

    public void UpgradeItem()
    {
        pistolNext++;
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItemBoxItem : MonoBehaviour
{
    public Text levelText;

    private void Awake()
    {
        levelText = GetComponent<Text>();
    }
    
    public void LvUp(int lv)
    {
        levelText.text = "Lv." + lv;
    }
}

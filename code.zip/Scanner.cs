using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scanner : MonoBehaviour
{
    public float scanRange;
    public LayerMask targetLayer;
    public RaycastHit2D[] targets;
    public Transform nearestTarget;
    public Transform[] inRangeTargets;
    public Transform randomTarget;
    private void FixedUpdate()
    {
        targets = Physics2D.CircleCastAll(transform.position, scanRange, Vector2.zero, 0, targetLayer);
        inRangeTargets = new Transform[targets.Length];
        nearestTarget = GetNearest();
        randomTarget = GetRandomTarget();
    }

    Transform GetNearest()
    {
        Transform result = null;
        float diff = 100;

        foreach (RaycastHit2D target in targets)
        {
            Vector3 myPos = transform.position;
            Vector3 targetPos = target.transform.position;
            float curDiff = Vector3.Distance(myPos, targetPos);

            if (curDiff < diff)
            {
                diff = curDiff;
                result = target.transform;
            }
        }

        return result;
    }

    Transform GetRandomTarget()
    {
        Transform result = null;
        int i = 0;
        foreach(RaycastHit2D target in targets)
        {
            inRangeTargets[i] = target.transform;
            i++;
            if (i >= inRangeTargets.Length) break;
        }
        if(inRangeTargets.Length > 0)
        {
            i = Random.Range(0, inRangeTargets.Length);
            result = inRangeTargets[i];
        }
        
        
        return result;
    }
}

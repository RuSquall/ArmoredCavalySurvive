using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItemBox : MonoBehaviour
{
    public static ItemBox instance; // Func calling
    public GameObject itemBox; // Prefeb
    public Transform itemBoxLocation; // Parent Location
    public Text text; // Text
    Image sprite; // Sprite
    
    
    private void Awake()
    {
        instance = this;
        text = GetComponent<Text>();
        sprite = GetComponent<Image>();
        
    }

    public void ItemAppend(Sprite Sp, int id)
    {
        GameObject item = Instantiate(itemBox, itemBoxLocation);
        item.name = "Item"+id;
        item.GetComponentsInChildren<Text>()[0].text = "Lv.1";
        item.GetComponentsInChildren<Image>()[0].sprite = Sp;
    }

    public void ItemLvUp(int id, int lv)
    {
        lv++;
        foreach(Transform it in itemBoxLocation)
        {
            if(it.name == "Item" + id)
            {
                it.GetComponentsInChildren<Text>()[0].text = "Lv." + lv;
            }
            
        }
        
    }

}

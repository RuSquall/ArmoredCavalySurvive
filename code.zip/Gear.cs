using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gear : MonoBehaviour
{
    public ItemData.ItemType type;
    public float rate;
    public float dmg;
    public void Init(ItemData data)
    {
        //Debug.Log("Gear Init");
        name = "Gear " + data.itemId;
        transform.parent = GameManager.instance.player.transform;
        transform.localPosition = Vector3.zero;

        type = data.itemType;
        rate = data.damages[0];
        ApplyGear();

    }

    public void LevelUp(float rate)
    {
        //Debug.Log("Gear LevelUp()");
        this.rate = rate;
        ApplyGear();


    }

    void ApplyGear()
    {
        //Debug.Log("ApplyGear - Itemdata.ItemType?: data" + type);

        
        switch (type)
        {
            case ItemData.ItemType.Glove:
                //Debug.Log("ItemType Glove");
                RateUp();
                break;
            case ItemData.ItemType.Shoe:
                //Debug.Log("ItemType Shoe");
                SpeedUp();
                break;
            case ItemData.ItemType.Armor:
                //Debug.Log("ItemType Armor");
                ArmorUp();
                break;
            case ItemData.ItemType.MaxHealthUp:
                //Debug.Log("ItemType MaxHealthUp");
                MaxHealthUp();
                break;
            case ItemData.ItemType.DamageUp:
                DamageUp();
                break;
        }
    }

    void SetRateAllWeapon()
    {
        Debug.Log("SetRateAllWeapon");
        Weapon[] weapons = transform.parent.GetComponentsInChildren<Weapon>();
        foreach (Weapon weapon in weapons)
        {
            float dmg = weapon.damage * Character.CharacterDamage;
            weapon.damage = dmg + (dmg * rate);
            Debug.Log("weapon.damage : " + weapon.damage);
            switch (weapon.id)
            {
                case 0:
                    float speed = 150 * Character.WeaponSpeed;
                    weapon.speed = speed + (speed * rate);
                    break;
                default:
                    speed = 0.5f * Character.WeaponRate;
                    weapon.speed = speed * (1f - rate);
                    break;
            }
        }
    }

    void RateUp() //�ʱ�ȭ, ����ȭ �̻���. �� �κ� ���� 1�� ���� �Ϸ�
    {
        Weapon[] weapons = transform.parent.GetComponentsInChildren<Weapon>();
        //Debug.Log("Function RateUp");
        foreach (Weapon weapon in weapons)
        {
            switch (weapon.id)
            {
                case 0:
                    float speed = 150 * Character.WeaponSpeed;
                    weapon.speed = speed + (speed * rate);
                    break;
                default:
                    speed = 0.5f * Character.WeaponRate;
                    weapon.speed = speed * (1f - rate);
                    break;
            }
        }
 
    }

    void SpeedUp()
    {
        //Debug.Log("Function SpeedUp");
        float speed = 3 * Character.Speed;
        GameManager.instance.player.speed = speed + (speed * rate);
    }

    void ArmorUp()
    {
        //Debug.Log("Function ArmorUp");
        float arm = 1f * Character.Armor;
        GameManager.instance.player.armor = arm - rate;
    }
    void MaxHealthUp()
    {
        //Debug.Log("Function MaxHealthUp");
        float maxhealth = 100f * Character.MaxHealth;
        // gethealth = GameManager.instance.maxHealth - maxhealth + rate; // �þ�� ü�¸�ŭ ȸ����Ű�� �κ� ����
        GameManager.instance.maxHealth = maxhealth + rate;
        //GameManager.instance.health += gethealth;
    }

    void DamageUp()
    {
        //dmg = 1f * GameManager.instance.player.damage + 1f * rate;
        //GameManager.instance.player.damage = dmg;
        float dama = 1f*Character.CharacterDamage;


        //Debug.Log("damage : " + dmg + " af damage : " + GameManager.instance.player.damage);
        Weapon[] weapons = transform.parent.GetComponentsInChildren<Weapon>();
        //Debug.Log("Function RateUp");
        foreach (Weapon weapon in weapons)
        {
            Debug.Log("Bef WeaponDamage : " + weapon.damage);
            weapon.damage *= dama + dama * rate;
            Debug.Log("weapon.damage : " + weapon.damage);
        }
    }
}

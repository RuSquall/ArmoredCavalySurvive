using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class Weapon : MonoBehaviour
{
    
    public int id;
    public int prefabId;
    public float damage;
    public int count;
    public float speed;

    Player player;
    

    WaitForSeconds wait;




    float timer1;
    float timer2;
    float timer3;
    int t3_0 = 1;
    int t3_1 = 1;
    float timer4;


    void Awake()
    {
        player = GameManager.instance.player;

        
    }

    void Update()
    {
        if (!GameManager.instance.isLive) return;
        switch (id)
        {
            case 0: // Shovel
                transform.Rotate(Vector3.forward * speed * Time.deltaTime);
                break;
            case 1: // Pistol
                timer1 += Time.deltaTime;
                if (timer1 > speed)
                {
                    timer1 = 0f;
                    Fire(12f);

                }
                break;
            case 2: // SMG
                timer2 += Time.deltaTime;
                if(timer2 > speed*1.7f)
                {
                    timer2 = -0.3f;
                    Fire(15f);
                    
                }
                break;
            case 3: // AR 0.1f 0.2f �κ��� ���� �ӵ��� ���� ������ �ö� ���� ª�������� ����?
                timer3 += Time.deltaTime;
                if(t3_0 == 1 && timer3 > speed * 2.5f)
                {
                    t3_0 = 0;
                    Fire(18f);
                }
                else if(t3_1 == 1 && timer3 > speed * 2.5f + 0.1f)
                {
                    t3_1 = 0;
                    Fire(18f);
                }
                else if(timer3 > speed * 2.5f + 0.2f)
                {
                    t3_0 = 1;
                    t3_1 = 1;
                    timer3 = -1f;
                    Fire(18f);
                }

                break;
            case 4: // Mortal
                timer4 += Time.deltaTime;
                if(timer4 > speed * 10f)
                {
                    timer4 = 0f;
                    Mortal();

                }
                break;
            default:
                break;
        }
    }
    public void LevelUp(float damage, int count)
    {
        this.damage = damage * Character.Damage;
        this.count += count;

        if (id == 0) Batch();

        player.BroadcastMessage("ApplyGear", SendMessageOptions.DontRequireReceiver);
    }
    public void Init(ItemData data)
    {
        //Basic set
        name = "Weapon " + data.itemId;
        transform.parent = player.transform;
        transform.localPosition  = Vector3.zero;

        
        

        // Property Set
        id = data.itemId;
        damage = data.baseDamage * Character.Damage;
        count = data.baseCount + Character.Count;

        for(int index = 0; index < GameManager.instance.pool.prefabs.Length; index++)
        {
            if(data.projectile == GameManager.instance.pool.prefabs[index])
            {
                prefabId = index;
                break;
            }
        }


        switch (id)
        {
            case 0:
                speed = 150 * Character.WeaponSpeed;
                Batch();
                break;

            default:
                speed = 0.5f * Character.WeaponRate;
                break;
        }

        //Hand Set
        

        

        Hand hand = player.hands[(int)data.itemType % 2];


        if (hand.spriter.sprite == null)
            hand.spriter.sprite = data.hand;
        else if(data.hand == GameManager.instance.leftSprite || data.hand == GameManager.instance.rightSprite)
        {
            hand.spriter.sprite = data.hand;
        }
        
        
        hand.gameObject.SetActive(true);

        player.BroadcastMessage("ApplyGear",SendMessageOptions.DontRequireReceiver);

    }

    void Batch()
    {
        for(int i = 0; i < count; i++) {
            Transform bullet;

            if (i < transform.childCount)
            {
                bullet = transform.GetChild(i);
            }
            else
            {
                bullet = GameManager.instance.pool.Get(prefabId).transform;
                bullet.parent = transform;
            }
            bullet.localPosition = Vector3.zero;
            bullet.localRotation = Quaternion.identity;

            Vector3 rotVec = Vector3.forward * 360 * i / count;
            bullet.Rotate(rotVec);
            bullet.Translate(bullet.up * 1.5f, Space.World);
            bullet.GetComponent<Bullet>().Init(damage, -100, Vector3.zero, 15f); // -100 is Infinity Per.
        }
    }

    void Fire(float vel)
    {
        if (!player.scanner.nearestTarget)
            return;

        Vector3 targetPos = player.scanner.nearestTarget.position;
        Vector3 dir = targetPos - transform.position;
        dir = dir.normalized;


        Transform bullet = GameManager.instance.pool.Get(prefabId).transform;
        bullet.position = transform.position;
        bullet.rotation = Quaternion.FromToRotation(Vector3.up, dir);
        bullet.GetComponent<Bullet>().Init(damage, count, dir, vel);
        AudioManager.instance.PlaySfx(AudioManager.Sfx.Range);
    }

    IEnumerator delay()
    {
        // 2. ��ĳ�� �ȿ� Ÿ�ٵ� �� ������ ��ġ ����
        Vector3 targetPos = player.scanner.randomTarget.position; // ������ ��ġ�� Ÿ�� ������ ������
        Vector3 dir = targetPos - transform.position; // ������ �Ÿ�
        // 3. ����

        Transform mor = GameManager.instance.pool.Get(prefabId).transform;
        mor.position = targetPos;
        mor.GetComponent<Bullet>().Init(damage, -100, dir, 0f);
        
        yield return wait = new WaitForSeconds(1f); ; // 0.15�� ������
        mor.gameObject.SetActive(false);
    }


    void Mortal()
    {
        //ĳ���ͷκ��� ���� �Ÿ� �̻��� ������ ��ġ�� ����
        // 1. ��ĳ�� �ȿ� Ÿ�� ������ ����
        if (!player.scanner.nearestTarget) return;

        StartCoroutine(delay());
    }
}
